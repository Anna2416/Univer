# Завдання
Використовуючи Page Object (PO) та Page Factory (PF), створити додаток, в
якому:

Описати сайт https://www.Amazon.com (або будь-який інший інтернет-
магазин) за допомогою PO and PF

Має бути від 4 -х сторінок ( Home Page, Search Page, Product Page , Shopping
Cart Page etc.)  

Написати від 15 до 20 тестів для перевірки вашої функціональності.

# Результат
![image](https://user-images.githubusercontent.com/72568844/206918364-53ddf699-bbb3-4753-a57d-f270a726e4a7.png)
![image](https://user-images.githubusercontent.com/72568844/206918368-38dcaf32-fe5b-40aa-b8da-a0133cec75f7.png)
